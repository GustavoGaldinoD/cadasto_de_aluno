from app import db, app

#definindo uma tabela
class Aluno(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(50), nullable=False)
    email = db.Column(db.String(50), unique=True)
    idade = db.Column(db.Integer)

    def __repr__(self):
        return f'<Aluno {self.nome}>' #objeto
    