from flask import request, render_template, redirect
from app import app, db
from models.aluno import Aluno

@app.route('/cadastrar', methods=['POST'])
def cadastrar():
    nome = request.form.get('nome')
    email = request.form.get('email')
    idade = request.form.get('idade')

    novo_aluno = Aluno(nome=nome, email=email, idade=idade)
    db.session.add(novo_aluno)
    db.session.commit()
    return redirect("/")

@app.route('/')
def listar():
    alunos = Aluno.query.all()
    render_template('lista.html', alunos=alunos)